# Usando o Netlify CLI (Opcional)

Se preferir usar o Netlify CLI para deploy, siga estes passos:

1. Instale o Netlify CLI globalmente:
   ```
   npm install -g netlify-cli
   ```

2. Faça login na sua conta Netlify:
   ```
   netlify login
   ```

3. Inicialize seu projeto Netlify (na pasta do projeto):
   ```
   netlify init
   ```

4. Para testar localmente:
   ```
   netlify dev
   ```

5. Para fazer deploy:
   ```
   netlify deploy --prod
   ```
